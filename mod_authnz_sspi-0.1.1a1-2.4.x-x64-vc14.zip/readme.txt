  February 18, 2017
                                  Apache Haus Distribution
                        
  Application:       mod_authnz_sspi 0.1.1-a1 for Apache 2.4.x x64
  Distribution File: mod_authnz_sspi-0.1.1a1-2.4.x-x64-vc14.zip
 
  Author: Ennio Zarlenga for mod_authnz_sspi
          Tim Costello for the original mod_auth_sspi
  Original Home: http://sourceforge.net/projects/mod-auth-sspi/

  Win32 binary by: Gregg
  Mail: info@apachehaus.com
  Home: http://www.apachehaus.com


  authnz_sspi module for Apache 2.4 x64 VC14 builds

  See doc/my_cfg.txt file for a sample config that worked for me on 
  Windows Vista using basic style auth.



